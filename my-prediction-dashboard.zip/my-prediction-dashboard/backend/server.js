
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const PredictionSchema = new mongoose.Schema({
  period: String,
  prediction: String,
  result: String,
  status: String,
});

const Prediction = mongoose.model("Prediction", PredictionSchema);

app.get("/api/history", async (req, res) => {
  const data = await Prediction.find().sort({ period: -1 }).limit(10);
  res.json(data);
});

app.get("/api/stats", async (req, res) => {
  const win = await Prediction.countDocuments({ status: "WIN" });
  const loss = await Prediction.countDocuments({ status: "LOSS" });
  const total = win + loss;
  const winRate = total ? (win / total) * 100 : 0;
  res.json({ winCount: win, lossCount: loss, winRate });
});

app.post("/api/predict", async (req, res) => {
  const { period } = req.body;
  const prediction = Math.random() < 0.5 ? "BIG" : "SMALL";

  const newPrediction = new Prediction({
    period,
    prediction,
    result: "",
    status: "Pending",
  });

  await newPrediction.save();
  res.json({ success: true, prediction });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
